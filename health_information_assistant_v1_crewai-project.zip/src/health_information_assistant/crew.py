import os
from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerperDevTool
)



@CrewBase
class HealthInformationAssistantCrew:
    """HealthInformationAssistant crew"""

    
    @agent
    def health_information_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["health_information_specialist"],
            tools=[SerperDevTool()],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gemini/gemini-1.5-flash",
                temperature=0.1,
            ),
        )
    

    
    @task
    def provide_health_information(self) -> Task:
        return Task(
            config=self.tasks_config["provide_health_information"],
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the HealthInformationAssistant crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
